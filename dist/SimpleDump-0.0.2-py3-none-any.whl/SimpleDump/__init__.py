name = "SimpleDump"
from .SimpleDump import var_dump
