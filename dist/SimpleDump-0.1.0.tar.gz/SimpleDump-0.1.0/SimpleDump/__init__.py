# __init__.py
from .SimpleDump import *

