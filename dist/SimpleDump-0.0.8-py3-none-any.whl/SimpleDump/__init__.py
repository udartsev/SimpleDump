# __init__.py
from .SimpleDump import var_dump, dd
