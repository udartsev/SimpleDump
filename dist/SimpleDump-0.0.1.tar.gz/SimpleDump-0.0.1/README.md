# var_dump for Python

This is a simple package which adds var_dump(), dd() and dump() functions for debugging Pythone code in PHP-style
[PythonVarDump](https://github.com/udartsev/PythonVarDump)

hen debugging in Python, ypu can frequently find it useful to simply stick a var_dump() in code to show what a variable is, what it`s value is, and the same for anything that it contains.


