name = "SimpleDump"
from . import var_dump

__all__ = ['var_dump']

